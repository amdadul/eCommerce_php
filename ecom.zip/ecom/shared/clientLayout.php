<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Moslin IT : E-Commerce</title>
<link rel="stylesheet" type="text/css" href="css/index.css" media="all">
<link rel="stylesheet" type="text/css" href="css/forms.css">
<link rel="stylesheet" media="all" href="css/adminMenu.css" type="text/css" /><style type="text/css">._css3m{display:none}</style><link rel="stylesheet" type="text/css" href="css/products.css">
<link rel="stylesheet" type="text/css" href="css/profile.css">
<link rel="stylesheet" type="text/css" href="css/comment.css" media="screen">
</head>

<body>
<div class="header">
Moslin IT E-Commerce Limited
</div>
<div class="main">
	<div class="menu">
        <?php include("shared/clientMenu.php");?>
    </div>
    
    <div class="content">
    <?php
		include('shared/controller.php');
    ?>
    </div>
</div>
<div class="footer">
	Copyright &copy; Moslin-IT.top || <?php print date('Y'); ?>
</div>
</body>
</html>