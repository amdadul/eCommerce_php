<?php
$pageName = "home";


if(isset($_GET['p']))
{
	$pageName = $_GET['p'];	
}
else if(isset($_GET['c']))
{
	$pageName = $_GET['c'];	
}

else
{
	$pageName = "home";	
}

if(!isset($_SESSION['type']))
{
	$_SESSION['id'] = "";
	$_SESSION['name'] = "";
	$_SESSION['image'] = "";
	$_SESSION['type'] = "";
	$_SESSION['chart'] = [];
	$_SESSION['price']="";
}



include_once("DAL/user.php");
$usr = new user();

include_once("DAL/activeuser.php");
$ausr = new activeuser();

include_once("DAL/blockuser.php");
$busr = new blockuser();

include_once('DAL/loginhistory.php');
$lh = new loginhistory();

$eemail="";
$epassword="";

if(isset($_POST['Login']))
{
	$usr->email = $_POST['email'];
	$usr->password = $_POST['password'];
	
	$er=0;
	$e="";
	if($usr->email == "")
	{
		$er++;
		$eemail = "Required";
	}
	
	if($usr->password == "")
	{
		$er++;
		$epassword = "Required";
	}
	
	if($er == 0)
	{
		
		if($usr->Login())
		{
			$_SESSION['id'] = $usr->id;
			$ausr->userId =$_SESSION['id'];
			$busr->userId =$_SESSION['id'];
			$lh->userId = $_SESSION['id'];
			$lh->dateTime = date("Y-m-d h:i:s");
			$lh->ip = $_SERVER['REMOTE_ADDR'];
			if($ausr->Alogin())
			{
				if(!$busr->Blogin())
					{
					$_SESSION['id'] = $usr->id;
					$_SESSION['name'] = $usr->name;
					$_SESSION['image'] = $usr->image;
					$_SESSION['type'] = $usr->type;
					$lh->Insert();
					}
					else
					{
						print '<script type="text/javascript">			
						var confirmResult = confirm(\'You Are Block To :'.$busr->blockTo.' \')	
						</script>';
					}
			}
			else
			{
				print '<script type="text/javascript">			
				var confirmResult = confirm(\'You Are not Active User !! \n please Active your Account \')	
				</script>';
			}
		}
		else
		{
			return $e;
		}
	}
	
}
if($pageName == "logout")
{
	$_SESSION['id'] = "";
	$_SESSION['name'] = "";
	$_SESSION['image'] = "";
	$_SESSION['type'] = "";
	$_SESSION['chart'] = [];
	$_SESSION['price']="";
}


function In_Chart($cid)
{
	if(is_array($_SESSION['chart']) and count($_SESSION['chart']))
	{
		if(in_array($cid, $_SESSION['chart']))
		{
			return true;
		}
	}
	return false;
}

if(isset($_GET['chart']))
{
	$a= $_SESSION["chart"];
	if(!in_array($_GET['chart'],$a))
	{
		$a[] =$_GET['chart'];
	}
	$_SESSION["chart"]=$a;
}

function Items()
{
	$a= $_SESSION["chart"];
	return 'Total : <a href="?c=chart">'.count($a)." Item in Chart</a>";
}

?>