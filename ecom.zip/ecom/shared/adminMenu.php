<ul id="css3menu1" class="topmenu">
	<li class="switch"><label onclick="" for="css3menu-switcher"></label></li>
	<li class="topfirst"><a href="?p=home" style="height:15px;line-height:15px;">Home</a></li>
	<li class="topmenu"><a href="#" style="height:15px;line-height:15px;"><span>Users</span></a>
	<ul>
		<li class="subfirst"><a href="?p=users">Users</a></li>
		<li><a href="?p=active_user">Active User</a></li>
		<li><a href="?p=block_user">Block User</a></li>
		<li><a href="?p=login_history">Login History</a></li>
	</ul></li>
	<li class="topmenu"><a href="#" style="height:15px;line-height:15px;"><span>Reference</span></a>
	<ul>
		<li class="subfirst"><a href="?p=country">Country</a></li>
		<li><a href="?p=city">City</a></li>
		<li><a href="?p=category">Category</a></li>
		<li><a href="#"><span>Product</span></a>
		<ul>
			<li class="subfirst"><a href="?p=brand">Brand</a></li>
			<li><a href="?p=color">Color</a></li>
			<li><a href="?p=size">Size</a></li>
			<li><a href="?p=unit">Unit</a></li>
		</ul></li>
		<li><a href="#"><span>Orders</span></a>
		<ul>
			<li class="subfirst"><a href="?p=payment_method">Payment Method</a></li>
			<li><a href="?p=status">Status</a></li>
            <li><a href="?p=order_status">Order Status</a></li>
		</ul></li>
	</ul></li>
	<li class="topmenu"><a href="#" style="height:15px;line-height:15px;"><span>Product</span></a>
	<ul>
		<li class="subfirst"><a href="?p=product">Product</a></li>
		<li><a href="?p=product_image">Image</a></li>
		<li><a href="?p=product_brochure">Brochure</a></li>
		<li><a href="?p=product_choice_list">Choice List</a></li>
		<li><a href="?p=product_like">Like</a></li>
		<li><a href="?p=product_dislike">Dislike</a></li>
		<li><a href="?p=product_rating">Rating</a></li>
		<li><a href="?p=product_review">Review</a></li>
	</ul></li>
	<li class="toplast"><a href="?p=orders" style="height:15px;line-height:15px;">Order</a></li>
   <?php
   if($_SESSION['type']=="")
   {
	   print' <li><a href="?c=register">Register</a></li> 
    <li><a href="?c=login">Login</a></li>';
   }
   else
   {
	    if($_SESSION['type']=="SA" || $_SESSION['type']=="A")
		{
			print '<li><a href="?cv=home">Client Layout</a></li>';
		}
   
	   print' <li><a href="?p=profile&uid='.$_SESSION["id"].'">'.$_SESSION["name"].'</a></li> 
    <li><a href="?c=logout">Logout</a></li>';
   }
   
   ?> 
   
</ul>