<ul id="css3menu1" class="topmenu">
	<li class="switch"><label onclick="" for="css3menu-switcher"></label></li>
	<li class="topfirst"><a href="?c=home" style="height:15px;line-height:15px;">Home</a></li>
	
	<li class="topmenu"><a href="#" style="height:15px;line-height:15px;"><span>Product</span></a> <?php LoadMenu();?></li>
	<li class="toplast"><a href="?c=orders" style="height:15px;line-height:15px;">My Order</a></li>
   <?php
   if($_SESSION['type']=="")
   {
	   print' <li><a href="?c=register">Register</a></li> 
    <li><a href="?c=login">Login</a></li>';
   }
   else
   {
	   if($_SESSION['type']=="SA" || $_SESSION['type']=="A")
		{
			print '<li><a href="?p=home">Admin Layout</a></li>';
		}
	   print' <li><a href="?c=profile&uid='.$_SESSION["id"].'">'.$_SESSION["name"].'</a></li> 
    <li><a href="?c=logout">Logout</a></li>';
   }
   
   ?> 
   
</ul>


<?php

function LoadMenu($chld = 0)
{
	$a = [];
	include_once("DAL/category.php");
	$ctg = new category();
		
	if($chld==0)
	{        
		$a = $ctg->SelectParent();		
	}
	else
	{
		$a= $ctg->SelectChild($chld);
	}
	if(count($a)>0)
	{
		print '<ul>';
		
		foreach($a as $v)
			{
				print '<li class="subfirst"><a href="?c=product&ctg='.$v['id'].'">'.$v['name'].'</a>';
				LoadMenu($v['id']);
				print '</li>';
			}
			
		print '</ul>';
	}
}

?>