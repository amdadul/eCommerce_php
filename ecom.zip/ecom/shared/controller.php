<?php
if(isset($_GET['p']))
{
	if(file_exists("private/".$pageName.".php"))
	{
		if($pageName != "home")
		{
		print '<span class="pageHead">'.ucwords(str_replace("_", " ", $pageName)).'</span><hr>';
		}
		if($_SESSION['type'] == "SA" || $_SESSION['type'] == "A")
		{
			
			include("private/".$pageName.".php");
		}
		else
		{
			print '<p>you have to login with admin account  for view this content</p>';
			include_once("clients/login.php");
		}
	}
	else
	{
		print '<span class="pageHead">Invalid Request</span><hr>';
		include("sicurity_warning.php");
	}
}



else if(isset($_GET['c']))
{
	if(file_exists("clients/".$pageName.".php"))
	{
		if($pageName != "home")
		{
		print '<span class="pageHead">'.ucwords(str_replace("_", " ", $pageName)).'</span><hr>';
		}
		if($pageName == "login" and $_SESSION['type'] !="")
		{
			print '<span class="success">You Have been Loged in Successfully</span>';
			if($pageName != "logout"){
				
					if(isset($_GET['c']) && ($_SESSION['type']=="SA" || $_SESSION['type']=="A"))
					{
						header('location:?p='.$pageName);
					}
				
				}
		}
		else
		{
			include("clients/".$pageName.".php");
		}
	}
	else
	{
		print '<span class="pageHead">Invalid Request</span><hr>';
		include("sicurity_warning.php");
	}
}

else
{
	if(file_exists("clients/".$pageName.".php"))
	{
		if($pageName != "home")
		{
		print '<span class="pageHead">'.ucwords(str_replace("_", " ", $pageName)).'</span><hr>';
		}
		if($pageName == "login" and $_SESSION['type'] !="")
		{
			print '<span class="success">You Have been Loged in Successfully</span>';
		}
		else
		{
			include("clients/".$pageName.".php");
		}
	}
	else
	{
		print '<span class="pageHead">Invalid Request</span><hr>';
		include("sicurity_warning.php");
	}
}
?>