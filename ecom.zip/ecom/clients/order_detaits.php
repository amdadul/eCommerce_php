<?php
include_once('DAL/orderdetails.php');

$order = new orderdetails();


$order->orderId= $_GET['oid'];

if(isset($_GET['id']))
{
	$order->id=$_GET['id'];
	if($order->Delete())
	{
		print '<span class="success">Data Deleted Successfully !!! </span>';
	}
	else
	{
		print '<span class="error">'.$order->error.'</span>';
	}
}

$order->pageName=$pageName;
$order->Table("view","");


?>