<?php
include_once('DAL/orders.php');
$o = new orders();
include_once('DAL/city.php');
$ct = new city();
include_once('DAL/paymentmethod.php');
$pm = new paymentmethod();
include_once('DAL/country.php');
$c = new country();
include_once('DAL/orderdetails.php');
$od = new orderdetails();

include_once('DAL/product.php');

$o->userId = $_SESSION['id'];
$o->total = $_SESSION['price'];

$eaddress="";
$ecity="";
$epayment="";
if(isset($_POST['order']))
{
	$o->Number= date("Y").'_'.date("m").'_'.date("d").'_'.rand(10,1000).'_'.$_SESSION['name'];
	$o->dateTime= date("Y-m-d h:i:s");
	$o->userId = $_SESSION['id'];
	$o->total = $_SESSION['price'];
	$o->vat =0;
	$o->discount = 0;
	if($_POST['city']==1)
	{
		$o->deliveryCharge = 100;
	}
	else
	{
		$o->deliveryCharge = 200;
	}
	$o->deliveryAddress = $_POST['address'];
	$o->cityId = $_POST['city'];
	$o->paymentMethodId = $_POST['payment'];
	
	
	$er=0;
	
	if($o->deliveryAddress=="")
	{
		$er++;
		$eaddress =" Requierd";
	}
	
	if(strlen($o->deliveryAddress)<10)
	{
		$er++;
		$eaddress =" Address Must have 10 Charecter";
	}
	
	if($o->cityId=="0")
	{
		$er++;
		$ecity =" Requierd";
	}
	
	if($o->paymentMethodId=="0")
	{
		$er++;
		$epayment =" Requierd";
	}
	
if($er==0)
{
	if($o->Insert())
		{
			$a = $_SESSION["chart"];
			$id=$o->lastId;
			foreach($a as $pid) 
				{
					$p = new product();
					$od = new orderdetails();
					$p->id = $pid;
					$p->SelectById();
					$od->orderId=$id;
					$od->productsId=$p->id;
					$od->serialNumber=$o->Number;
					$od->vat=$p->vat;
					$od->discount=$p->discount;
					$subtotal =($p->price 
								+ ($p->price * $p->vat / 100) 
								- ($p->price * $p->discount / 100));
					$od->rate =$subtotal;
					$od->qty ="1 pec";
					
					if($od->Insert())
					{
						header("location:?c=view_order&id=".$id);
					}
					else
					{
						print $od->error;
					}
				}
			print '<span class="success">Order Submitted Successfully</span>';	
			$o = new orders();
		}
		else
		{
			print '<span class="error">'.$o->error.'</span>';	
		}
}
}

if($o->userId == "")
{
	print 'You Must Login First';
}
else if($o->total == "")
{
	print 'You Must Add At Lest 1 Item To Chart';
}
else
{
	$html->BeginForm("","Confirm Order");
	
	$html->FieldTextArea("address",$o->deliveryAddress);
	$html->Error($eaddress);
	$html->BreakLine();
	
	$html->FieldSelect("city", $ct->Option($o->cityId));
	$html->Error($ecity);
	$html->BreakLine();
	
	$html->FieldSelect("payment", $pm->Option($o->paymentMethodId));
	$html->Error($epayment);
	$html->BreakLine();
	
	$html->EndForm("order","order");
}
?>
