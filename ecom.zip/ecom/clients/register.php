<?php
include_once('DAL/user.php');
$u = new user();

include_once('DAL/city.php');
$c = new city();


$ename = "";
$eemail = "";
$epassword = "";
$econtact = "";
$etype = "";
$eaddress = "";
$ecity = "";
$eimage = "";


if(isset($_POST['submit']))
{
	$u->name = $_POST['name'];
	$u->email = $_POST['email'];
	$u->password = $_POST['password'];
	$u->contact = $_POST["contact"];
	$u->type = "U";
	$u->address = $_POST['address'];
	$u->cityId = $_POST['city'];
	$u->createDate = date("Y-m-d h:i:s");
	$u->createIp = $_SERVER['REMOTE_ADDR'];
	$u->image = $_FILES['image'];
	
	
	
	$er = 0;
	
	if($u->name == "")
	{
		$er++;
		$ename = "Required";
	}
	if($u->email == "")
	{
		$er++;
		$eemail = "Required";
	}
	
	if($u->password == "")
	{
		$er++;
		$epassword = "Required";
	}
	
	if($u->contact == "")
	{
		$er++;
		$econtact = "Required";
	}
	
	if($u->type == "")
	{
		$er++;
		$etype = "Required";
	}
	
	if($u->address == "")
	{
		$er++;
		$eaddress = "Required";
	}
	
	if($u->cityId == "0")
	{
		$er++;
		$ecity = "Required";
	}
	
	if($u->image["name"] == "")
	{
		$er++;
		$eimage = "Required";
	}
	else if(!$html->validImage($u->image["name"]))
	{
		$er++;
		$eimage = "Only JPEG and PNG Supported";	
	}
	else if($u->image["size"] > (1024 * 1024))
	{
		$er++;
		$eimage = "Must Less Than 1 MB";
	}
	
	if($er == 0)
	{
		if($u->Insert())
		{
			$sp = $u->image["tmp_name"];
			$dp = "upload/userImage/".$u->lastId."_".$u->image["name"];
			
			move_uploaded_file($sp, $dp);
			
			print '<span class="success">Registration  Successfully</span>';	
			$u = new user();
		}
		else
		{
			print '<span class="error">'.$u->error.'</span>';	
		}
	}
}

$html->BeginForm('enctype="multipart/form-data"');

$html->FieldText("name", $u->name);
$html->Error($ename);
$html->BreakLine();

$html->FieldText("email", $u->email);
$html->Error($eemail);
$html->BreakLine();

$html->FieldPassword("password");
$html->Error($epassword);
$html->BreakLine();

$html->FieldText("contact", $u->contact);
$html->Error($econtact);
$html->BreakLine();


$html->FieldTextArea("address", $u->address);
$html->BreakLine();

$html->FieldSelect("city", $c->Option($u->cityId));
$html->Error($ecity);
$html->BreakLine();

$html->FieldFile("image");
$html->Error($eimage);
$html->BreakLine();


$html->EndForm("submit","Register");

?>
