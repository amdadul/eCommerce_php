<script type="text/javascript">     
    function PrintDiv() {    
       var divToPrint = document.getElementById('viewMain');
       var popupWin = window.open('', '_blank', 'width=400,height=300');
       popupWin.document.open();
	   popupWin.document.bgColor
       popupWin.document.write('<html><head></head><body bgcolor="#478DF9" color="#ffffff" onload="window.print()"> ' + divToPrint.innerHTML  + '</html>');
        popupWin.document.close();
            }
 </script>

<?php
include_once('DAL/orders.php');

$order = new orders();


$order->id=$_GET['id'];

$vo = $order->Select();

if(count($vo) >0)
{
	print '<div class="viewMain" id="viewMain" >';
	print '<span>Order Id : '.$vo[0]['id'].'</span><br>';
	print '<span>Order Number : '.$vo[0]['number'].'</span><br>';
	print '<span>User : '.$vo[0]['user'].'</span><br>';
	print '<span>Date Time : '.$vo[0]['dateTime'].'</span><br>';
	print '<span>Total : '.$vo[0]['total'].'</span><br>';
	print '<span>Vat : '.$vo[0]['vat'].'</span><br>';
	print '<span>Discount : '.$vo[0]["discount"].'</span><br>';
	print '<span>Delivery Charge : '.$vo[0]["deliveryCharge"].'</span><br>';
	print '<span>Delivery Address : '.$vo[0]["deliveryAddress"].'</span><br>';
	print '<span>City : '.$vo[0]["city"].'</span><br>';
	print '<span>Payment Method : '.$vo[0]["paymentmethod"].'</span>';
	print '</div>';
	
	
	
	print '<button class="print" value="print" onclick="PrintDiv();" >Print</button>';
	

}

?>