<?php
include_once('DAL/product.php');

$a = $_SESSION["chart"];
$total=0;
print '<table>';
print'<th>Name</td><th>Price</td><th>Vat</td><th>Discount</td><th>Total</td>';
foreach($a as $pid) 
{
	$p = new product();
	$p->id = $pid;
	$p->SelectById();
	$total=0;
	print'<tr>';
	
	print'<td>'.$p->name.'</td>';
	print'<td>'.$p->price.'</td>';
	print'<td>'.$p->vat.'</td>';
	print'<td>'.$p->discount.'</td>';
	print'<td> <b>BDT '.($p->price 
				+ ($p->price * $p->vat / 100) 
				- ($p->price * $p->discount / 100)).' </b></td>';
				
	$subtotal []["price"] =($p->price 
				+ ($p->price * $p->vat / 100) 
				- ($p->price * $p->discount / 100));
				
	
	print '</tr>';
}
if(count($a) !=0)
{
	foreach($subtotal as $t)
	{
		
			$total +=$t["price"];
		
	}
}
print '<tr><td></td><td></td><td></td><td> </td><td></td></tr>';
print '<tr><td></td><td></td><td></td><td>Total : </td><td>'.$total.'</td></tr>';
if($total !=0)
{
	$pr=$_SESSION['price'];
	$pr=$total;
	$_SESSION['price']=$pr;
}
print '</table>';
print '<a href="?c=product">Continue Shoping </a>';
print '<a href="?c=confirm">Confirm Order </a>';


?>