<script type="text/javascript">

function changeImage(v)
{
	document.getElementById("mainImage").setAttribute("src",v);
}
</script>

<?php
include_once('DAL/productImage.php');
include_once('DAL/productlike.php');
include_once('DAL/productdislike.php');
include_once('DAL/productreview.php');
include_once('DAL/productrating.php');
include_once('DAL/product.php');

if(isset($_GET["pidl"]))
{
	$pl = new productlike();
	$pl->productId = $_GET['pid'];
	$pl->userId = $_SESSION['id'];
	$pl->dateTime = date("Y-m-d h:m:s");
	$pl->Insert();
}

if(isset($_GET["pdid"]))
{
	$pdl = new productdislike();
	$pdl->productId = $_GET['pdid'];
	$pdl->userId = $_SESSION['id'];
	$pdl->dateTime = date("Y-m-d h:m:s");
	$pdl->Insert();
}




$p = new product();

$p->id = $_GET['pid'];

$table = $p->Select();

$row =$table[0];

		print '<div class="gallery">';
		findImageFirst($row['id']);
		print '<div>';
		findImage($row['id']);
		print '</div>';
		print '</div>';
		print '<div class="productprofile">';
		print '<span><b>Name : '.$row["name"].'</b></span>';
		print '<span>Code :[ '.$row["code"].' ]</span>';
		
		print '<span> 
				Brand : '.$row["brand"].' <br> 
				Category : '.$row["category"].' <br>
				Stock : '.$row["stock"]." ".$row["unit"].'</span>';
				
		print '<span>Price :<op> '.$row["price"].'</op> + Vat :'.$row["vat"].' % - Dis :'.$row["discount"].' % <b>Total : '.($row["price"] 
				+ ($row["price"] * $row["vat"] / 100) 
				- ($row["price"] * $row["discount"] / 100)).'</b></span>';
				
		print '<span>Color : '.$row["color"].'<br> Size : '.$row["size"].'<br> Model : '.$row["model"].'</span>';
		
		
		
		
		print '<p><b> Tags : '.$row["tags"].'</b></p> <p> Description : '.$row["description"].'</p>';
		print '<span>';
		likeComments($row["id"]);
		print '</span>';		
				
		print '</div>';
		
	$prd = new productreview();
	$pr = new productrating();
	$prd->productId =$row['id'];
	$pr->productId =$row['id'];
	
	
	$erating ="";
	if(isset($_POST['rate']))
{
	$pr->productId =$row['id'];
	$pr->userId = $_SESSION['id'];
	
	if(isset($_POST['rating']))
		$pr->ratings = $_POST['rating'];
	
	$pr->dateTime = date("Y-m-d h:i:s");	
	
	$er = 0;
	
	if($pr->userId == "")
		{
			$er++;
			print '<script type="text/javascript">			
				var confirmResult = confirm(\'You Must login First !! \n Log-in Now ??? \')	
				</script>';
			
		}
	
	if($pr->ratings == "")
	{
		$er++;
		$erating = "Required";
	}
	
	if($er == 0)
	{
		if($pr->Insert())
		{			
				
			$pr = new productrating();
		}
		else
		{
			print '<span class="error">'.$pr->error.'</span>';	
		}
	}
}

	
	$ereview = "";
	if(isset($_POST['comment']))
	{
		$prd->productId =$row['id'];
		$prd->userId = $_SESSION['id'];
		$prd->review = $_POST['Comments'];
		$prd->dateTime = date("Y-m-d h:m:s");
		
		$er=0;
		if($prd->review == "")
		{
			$er++;
			$ereview = " Required";
		}
		else if(strlen($prd->review) > 4000 || strlen($prd->review) <5)
		{
			$er++;
			$ereview = " Comment must have 5 to 4000 character";
		}
		if($prd->userId == "")
		{
			$er++;
			print '<script type="text/javascript">			
				var confirmResult = confirm(\'You Must login First !! \n Log-in Now ??? \')	
				</script>';
			
		}
	if($er == 0)
	{
		if(!$prd->Insert())
		{
			$ereview = $prd->error;
		}
		else
		{
			$prd->review ="";
		}
	}
	
	}
		
	
		
	$a = $prd->Select();
	print '<div class="comments">';
	if(!Is_Rating($p->id))
	{
		$html->BeginForm("","");
		$html->FieldRadio("ratings : ","rating",1);
		$html->Error($erating);
		$html->FieldRadio("","rating",2);
		$html->FieldRadio("","rating",3);
		$html->FieldRadio("","rating",4);
		$html->FieldRadio("","rating",5);
		$html->EndForm("rate","rate");
	}
	
	$html->BeginForm("","");
	$html->FieldTextArea("Comments",$prd->review);
	$html->Error($ereview);
	$html->BreakLine();
	$html->EndForm("comment","comment");
	
	foreach($a as $item)
	{
		print '<div class="comment">';
		print '<span>';
		print '<div class="pc"><a href="?c=profile&uid='.$item["userId"].'">';
		if(file_exists('upload/userImage/'.$item["userId"].'_'.$item["image"]))
		{
		print '<img  src="upload/userImage/'.$item["userId"].'_'.$item["image"].'" id="pp" />';
		}
		
		else
		{
			print '<img id="pp" src="images/noimage.jpg" alt="No Image" title="No Image"/>';
		}
		print '</div></a>';
		print '<b>'.$item["user"].'</b> : '.$item["dateTime"].'</span>';
		print '<p>'.$item["review"].'</p>';
		print '</div>';
	}
	print '</div>';
	
function findImage($id)
{
	$pi = new productImage();
	$pi->productId = $id;
	$a =$pi->Select();
	if(count($a) > 0)
	{
		foreach($a as $row)
		{
			$ipath = 'upload/productImage/'.$row["id"].'_'.$row["image"];
			if(file_exists($ipath))
			{
			print '<img onClick="changeImage(\''.$ipath.'\')" src="'.$ipath.'"  />';
			}
			
			else
			{
				print '<img src="images/noimage.jpg" alt="No Image" title="No Image"/>';
			}
		}
		
	}
	else
	{
		print '<img src="images/noimage.jpg" alt="No Image" title="No Image"/>';
	}
}


function findImageFirst($id)
{
	$pi = new productImage();
	$pi->productId = $id;
	$a =$pi->Select();
	if(count($a) > 0)
	{
		
		if(file_exists('upload/productImage/'.$a[0]["id"].'_'.$a[0]["image"]))
		{
		print '<img  src="upload/productImage/'.$a[0]["id"].'_'.$a[0]["image"].'" id="mainImage" />';
		}
		
		else
		{
			print '<img id="mainImage" src="images/noimage.jpg" alt="No Image" title="No Image"/>';
		}
		
	}
	else
	{
		print '<img id="mainImage" src="images/noimage.jpg" alt="No Image" title="No Image"/>';
	}
}


function likeComments($id)
{
	$pl = new productlike();	
	$pr = new productreview();
	
	$pl->productId = $id;	
	$pr->productId = $id;
	
	
	$al =$pl->Select();	
	$ar =$pr->Select();
	$url ="?c=product";
	
	if(isset($_GET['ctg']))
		$url .="&ctg=".$_GET['ctg'];
		
	if($_SESSION['type']==""  || Is_Dislike($id))
	{
		print 'Like';
	}
	else
	{
		if(Is_like($id))
		{
			print 'Liked';
		}
		else
		{
			print '<a href="'.$url."&pidl=".$id.'">Like</a>';
		}
	}
	print ' : <a href="#" >'.count($al).'</a> | ';
	
	dislike($id);
	rating($id);
	print 'Comments : <a href="#">'.count($ar).'</a>  ';
}

function dislike($id)
{
	
	$pdl = new productdislike();
		
	$pdl->productId = $id;
		
	$adl =$pdl->Select();
	
	$url ="?c=home";
	
	if(isset($_GET['ctg']))
		$url .="&ctg=".$_GET['ctg'];
		
	if($_SESSION['type']=="" || Is_like($id))
	{
		print 'DisLike';
	}
	else
	{
		if(Is_DisLike($id))
		{
			print 'DisLiked';
		}
		else
		{
			print '<a href="'.$url."&pdid=".$id.'">DisLike</a>';
		}
	}
	print ' : <a href="#" >'.count($adl).'</a> | ';
	
	
}


function rating($id)
{
	
	$prt = new productrating();
		
	$prt->productId = $id;
		
	$art =$prt->Select();
	
	$url ="?c=home";
	
	if(isset($_GET['ctg']))
		$url .="&ctg=".$_GET['ctg'];
		
	if($_SESSION['type']=="" || Is_Rating($id))
	{
		print 'Rating';
	}
	else
	{		
			print '<a href="#">Rate</a>';
		
	}
	
	print ' : <a href="#" >'. View_Rating($id).'</a> | ';
	
	
}



function Is_Like($id)
{
	$pl = new productlike();
	$pl->productId = $id;
	
	$s=$pl->Select();
	foreach($s as $l)
	if($l['userId']==$_SESSION['id'])
		return true;
		
	return false;
	
}

function Is_DisLike($id)
{
	$pdl = new productdislike();
	$pdl->productId = $id;
	
	$d=$pdl->Select();
	foreach($d as $dl)
	if($dl['userId']==$_SESSION['id'])
		return true;
		
	return false;
	
}

function Is_Rating($id)
{
	$prt = new productrating();
	$prt->productId = $id;
	
	$d=$prt->Select();
	foreach($d as $rt)
	if($rt['userId']==$_SESSION['id'])
		return true;
		
	return false;
	
}

function View_Rating($id)
{
	$prt = new productrating();
	$prt->productId = $id;
	$vtotal=0;
	$d=$prt->Select();
	foreach($d as $rt){
	$vrt =$rt['ratings'];
	$vtotal += $vrt;
	}
	$dv = count($d);
	if($vtotal==0)
		return  '0 %';
		
	return  $vtotal/$dv.' %';
}


?>