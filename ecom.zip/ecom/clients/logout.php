
<b><i>You have been successfully logout From uor System </i></b>