<?php
if(isset($e))
{
	print '<span class="error">Email or Password are Invalid !!!</span>';
}

$html->BeginForm();


$html->FieldText("email", "");
$html->Error($eemail);
$html->BreakLine();

$html->FieldPassword("password");
$html->Error($epassword);
$html->BreakLine();



$html->EndForm("Login","Login");


?>