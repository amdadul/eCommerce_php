<?php
include_once('DAL/user.php');
$u = new user();
$u->id = $_SESSION['id'];
include_once('DAL/city.php');
$c = new city();


$ename = "";
$eemail = "";
$epassword = "";
$econtact = "";
$etype = "";
$eaddress = "";
$ecity = "";
$eimage = "";


if(isset($_POST['submit']))
{
	$u->name = $_POST['name'];
	$u->email = $_POST['email'];
	$u->password = $_POST['password'];
	$u->contact = $_POST["contact"];
	
	$u->address = $_POST['address'];
	$u->cityId = $_POST['city'];
	$u->createDate = date("Y-m-d h:i:s");
	$u->createIp = $_SERVER['REMOTE_ADDR'];
	
	
	
	$er = 0;
	
	if($u->name == "")
	{
		$er++;
		$ename = "Required";
	}
	if($u->email == "")
	{
		$er++;
		$eemail = "Required";
	}
	
	if($u->password == "")
	{
		$er++;
		$epassword = "Required";
	}
	
	if($u->contact == "")
	{
		$er++;
		$econtact = "Required";
	}
	
	
	
	if($u->address == "")
	{
		$er++;
		$eaddress = "Required";
	}
	
	if($u->cityId == "0")
	{
		$er++;
		$ecity = "Required";
	}
	
	
	
	if($er == 0)
	{
		if($u->Update())
		{
			
			
			print '<span class="success">Profile Updated  Successfully</span>';	
			$u = new user();
		}
		else
		{
			print '<span class="error">'.$u->error.'</span>';	
		}
	}
}
else
{
	$u->SelectById();
}

$html->BeginForm('enctype="multipart/form-data"');

$html->FieldText("name", $u->name);
$html->Error($ename);
$html->BreakLine();

$html->FieldText("email", $u->email);
$html->Error($eemail);
$html->BreakLine();

$html->FieldPassword("password");
$html->Error($epassword);
$html->BreakLine();

$html->FieldText("contact", $u->contact);
$html->Error($econtact);
$html->BreakLine();

$html->FieldTextArea("address", $u->address);
$html->BreakLine();

$html->FieldSelect("city", $c->Option($u->cityId));
$html->Error($ecity);
$html->BreakLine();


$html->EndForm("submit","Update");

?>
