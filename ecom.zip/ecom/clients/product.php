<?php
print '<div class="items">'.Items().'</div>';

include_once('DAL/productImage.php');
include_once('DAL/productlike.php');
include_once('DAL/productdislike.php');
include_once('DAL/productreview.php');
include_once('DAL/productrating.php');
include_once('DAL/product.php');

if(isset($_GET["pid"]))
{
	$pl = new productlike();
	$pl->productId = $_GET['pid'];
	$pl->userId = $_SESSION['id'];
	$pl->dateTime = date("Y-m-d h:m:s");
	$pl->Insert();
}

if(isset($_GET["pdid"]))
{
	$pdl = new productdislike();
	$pdl->productId = $_GET['pdid'];
	$pdl->userId = $_SESSION['id'];
	$pdl->dateTime = date("Y-m-d h:m:s");
	$pdl->Insert();
}

$p = new product();

if(isset($_GET["ctg"]))
{
	$p->categoryId = $_GET["ctg"];
}

$table = $p->Select();



foreach($table as $row)
	{
		print '<div class="product" >';
		
		print '<span><b>'.$row["name"].'</b>[ '.$row["code"].' ]</span>';
		
		print '<span> 
				Brand : '.$row["brand"].' 
				Category : '.$row["category"].' 
				Stock : '.$row["stock"]." ".$row["unit"].'</span>';
				
		print '<span>Price :<op> '.$row["price"].'</op> + Vat :'.$row["vat"].' % - Dis :'.$row["discount"].' % <b>Total : '.($row["price"] 
				+ ($row["price"] * $row["vat"] / 100) 
				- ($row["price"] * $row["discount"] / 100)).'</b></span>';
				
		print '<span>Color : '.$row["color"].' Size : '.$row["size"].' Model : '.$row["model"].'</span>';
		
		print '<span>';
		$url ="?c=product";
		if(isset($_GET['ctg']))
		$url .="&ctg=".$_GET['ctg'];
		
		if(In_Chart($row["id"]))
		{
			print 'Added To Chart';
		}
		else
		{
			print '<a href="'.$url.'&chart='.$row["id"].'">Add To Chart</a>';
		}
		
		print '</span>';
		print'<a href="?c=product_profile&pid='.$row["id"].'">';
		
		findImage($row["id"]);
		print '</a>';
		print '<span>';
		likeComments($row["id"]);
		print '</span>';
		
		
		print '<p><b>'.wordwrap($row["tags"],15,"<br>\n").'</b> <br>'.$row["description"].'</p>';		
		
		
		print '</div>';
	}
function findImage($id)
{
	$pi = new productImage();
	$pi->productId = $id;
	$a =$pi->Select();
	if(count($a) > 0)
	{
		if(file_exists('upload/productImage/'.$a[0]["id"].'_'.$a[0]["image"]))
		{			
			print '<img src="upload/productImage/'.$a[0]["id"].'_'.$a[0]["image"].'"  title="'.count($a).' More Images"/>';
		}
		
		else
		{
			print '<img src="images/noimage.jpg" alt="No Image" title="No Image"/>';
		}
		
	}
	else
	{
		
		print '<img src="images/noimage.jpg" alt="No Image" title="No Image"/>';
		
	}
}

function likeComments($id)
{
	$pl = new productlike();	
	$pr = new productreview();
	
	$pl->productId = $id;	
	$pr->productId = $id;
	
	
	$al =$pl->Select();	
	$ar =$pr->Select();
	$url ="?c=product";
	
	if(isset($_GET['ctg']))
		$url .="&ctg=".$_GET['ctg'];
		
	if($_SESSION['type']==""  || Is_Dislike($id))
	{
		print 'Like';
	}
	else
	{
		if(Is_like($id))
		{
			print 'Liked';
		}
		else
		{
			print '<a href="'.$url."&pid=".$id.'">Like</a>';
		}
	}
	print ' : <a href="#" title="'.View_Like($id).'" >'.count($al).'</a> | ';
	
	dislike($id);
	rating($id);
	print 'Comments : <a href="?c=product_profile&pid='.$id.'">'.count($ar).'</a>  ';
}

function dislike($id)
{
	
	$pdl = new productdislike();
		
	$pdl->productId = $id;
		
	$adl =$pdl->Select();
	
	$url ="?c=home";
	
	if(isset($_GET['ctg']))
		$url .="&ctg=".$_GET['ctg'];
		
	if($_SESSION['type']=="" || Is_like($id))
	{
		print 'DisLike';
	}
	else
	{
		if(Is_DisLike($id))
		{
			print 'DisLiked';
		}
		else
		{
			print '<a href="'.$url."&pdid=".$id.'">DisLike</a>';
		}
	}
	print ' : <a href="#" title="'.View_DisLike($id).'" >'.count($adl).'</a> | ';
	
	
}


function rating($id)
{
	
	$prt = new productrating();
		
	$prt->productId = $id;
		
	$art =$prt->Select();
	
	$url ="?c=home";
	
	if(isset($_GET['ctg']))
		$url .="&ctg=".$_GET['ctg'];
		
	if($_SESSION['type']=="" || Is_Rating($id))
	{
		print 'Rating';
	}
	else
	{		
			print '<a href="?c=product_profile&pid='.$id.'">Rate</a>';
		
	}
	
	print ' : <a href="#" >'. View_Rating($id).'</a> | ';
	
	
}



function Is_Like($id)
{
	$pl = new productlike();
	$pl->productId = $id;
	
	$s=$pl->Select();
	foreach($s as $l)
	if($l['userId']==$_SESSION['id'])
		return true;
		
	return false;
	
}

function View_Like($id)
{
	$pl = new productlike();
	$pl->productId = $id;
	$lu = "";
	$s=$pl->Select();
	foreach($s as $l)
	{
		$lu .= $l['user']."\n";
	}
	return $lu;
}

function Is_DisLike($id)
{
	$pdl = new productdislike();
	$pdl->productId = $id;
	
	$d=$pdl->Select();
	foreach($d as $dl)
	if($dl['userId']==$_SESSION['id'])
		return true;
		
	return false;
	
}

function View_DisLike($id)
{
	$pdl = new productdislike();
	$pdl->productId = $id;
	$dlu = "";
	$d=$pdl->Select();
	foreach($d as $dl)
	{
		$dlu .= $dl['user']."\n";
	}
	return $dlu;
	
}


function Is_Rating($id)
{
	$prt = new productrating();
	$prt->productId = $id;
	
	$d=$prt->Select();
	foreach($d as $rt)
	if($rt['userId']==$_SESSION['id'])
		return true;
		
	return false;
	
}

function View_Rating($id)
{
	$prt = new productrating();
	$prt->productId = $id;
	$vtotal=0;
	$d=$prt->Select();
	foreach($d as $rt){
	$vrt =$rt['ratings'];
	$vtotal += $vrt;
	}
	$dv = count($d);
	if($vtotal==0)
		return  '0 %';
		
	return  $vtotal/$dv.' %';
}


?>