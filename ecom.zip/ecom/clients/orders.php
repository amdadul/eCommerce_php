<?php
include_once('DAL/orders.php');

$order = new orders();


$order->userId= $_SESSION['id'];

if(isset($_GET['id']))
{
	$order->id=$_GET['id'];
	if($order->Delete())
	{
		print '<span class="success">Data Deleted Successfully !!! </span>';
	}
	else
	{
		print '<span class="error">'.$order->error.'</span>';
	}
}

$order->pageName=$pageName;
if($order->userId == "")
{
	print 'You Must Login First';
}
else
{
	$order->Table("order","");
}


?>