<?php
include_once('DAL/user.php');
$u = new user();

include_once('DAL/activeuser.php');
$au = new activeuser();


$euser = "";


if(isset($_POST['submit']))
{
	$au->userId = $_POST['user'];
	
	$au->dateTime = date("Y-m-d h:i:s");
	$au->ip = $_SERVER['REMOTE_ADDR'];
	
	
	
	
	$er = 0;
	
	if($au->userId == "0")
	{
		$er++;
		$ename = "Required";
	}
	
	
	if($er == 0)
	{
		if($au->Insert())
		{
			
			
			print '<span class="success">User active Successfully</span>';	
			$au = new activeuser();
		}
		else
		{
			print '<span class="error">'.$au->error.'</span>';	
		}
	}
}

$html->BeginForm();


$html->FieldSelect("user", $u->Option($au->userId));
$html->Error($euser);
$html->BreakLine();

$html->EndForm();

?>
