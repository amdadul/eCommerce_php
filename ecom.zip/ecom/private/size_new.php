<?php
include_once('DAL/size.php');
$s = new size();

$ename = "";

if(isset($_POST['submit']))
{
	$s->name = $_POST['name'];
	$s->description = $_POST["description"];
	
	$er = 0;
	
	if($s->name == "")
	{
		$er++;
		$ename = "Required";
	}
	
	if($er == 0)
	{
		if($s->Insert())
		{
			print '<span class="success">Size Inserted Successfully</span>';	
			$s = new size();
		}
		else
		{
			print '<span class="error">Error</span>';	
		}
	}
}

$html->BeginForm();

$html->FieldText("name",$s->name);
$html->Error($ename);
$html->BreakLine();

$html->FieldTextArea("description", $s->description);
$html->BreakLine();

$html->EndForm();
?>
