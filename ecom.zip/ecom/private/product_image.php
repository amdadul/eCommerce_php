<?php
$html->NewLink($pageName);
include_once('DAL/productImage.php');
$pi = new productImage();

if(isset($_GET['id']))
{
	$pi->id=$_GET['id'];
	if($pi->Delete())
	{
		print '<span class="success">Data Deleted Successfully !!! </span>';
	}
	else
	{
		print '<span class="error">'.$pi->error.'</span>';
	}
}

$pi->pageName=$pageName;
$pi->Table("image",'<img src="upload/productImage/#replace#"  height="100px" alt=""/>');
?>