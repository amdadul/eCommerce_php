<?php
include_once('DAL/loginhistory.php');

$lh = new loginhistory();
$html->NewLink($pageName);

if(isset($_GET['id']))
{
	$lh->id=$_GET['id'];
	if($lh->Delete())
	{
		print '<span class="success">Data Deleted Successfully !!! </span>';
	}
	else
	{
		print '<span class="error">'.$lh->error.'</span>';
	}
}

$lh->pageName=$pageName;
$lh->Table();


?>