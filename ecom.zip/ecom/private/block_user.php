<?php
include_once('DAL/blockuser.php');

$bu = new blockuser();
$html->NewLink($pageName);

if(isset($_GET['id']))
{
	$bu->id=$_GET['id'];
	if($bu->Delete())
	{
		print '<span class="success">Data Deleted Successfully !!! </span>';
	}
	else
	{
		print '<span class="error">'.$bu->error.'</span>';
	}
}

$bu->pageName=$pageName;
$bu->Table();
/*if($bu->blockTo <= date("Y-m-d"))
{
	$bu->id=$bu['id'];
	$bu->Delete();
								
}
*/
?>