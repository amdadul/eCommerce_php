

<?php
include_once('DAL/user.php');
$u = new user();

$u->id = $_SESSION['id'];

$table = $u->Select();

$row =$table[0];

		print '<div class="pf">';
		if(file_exists('upload/userImage/'.$u->id.'_'.$row["image"]))
		{
		print '<img  src="upload/userImage/'.$u->id.'_'.$row["image"].'" id="pp" />';
		}
		
		else
		{
			print '<img id="pp" src="images/noimage.jpg" alt="No Image" title="No Image"/>';
		}
		print '<a href="?p=upload_image">Upload Image</a>';
		print '</div>';
		print '<div class="ps">';
		print '<span><b>Name : '.$row["name"].'</b></span>';
		print '<span>Email : '.$row["email"].' </span>';
		print '<span>Contact : 0'.$row["contact"].'</span>';
		print '<a href="?p=edit_profile">Edit Profile</a>';
		print '</div>';
		
		print '<div class="ditails">';
		print '<span> Type : '.$row["type"].' </span>
				<span>Address : '.$row["address"]."</span>
				<span>City : ".$row["city"].'</span>
				<span>Country : '.$row["country"].'</span>';
				
		print '<span>Crate Date : '.$row["createDate"].'</span>';
				
		print '<span>Create IP : '.$row["createIp"].'</span>';
		
						
		print '</div>';

?>