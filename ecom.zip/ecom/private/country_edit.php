<?php
include_once('DAL/country.php');
$c = new country();
$c->id = $_GET['id'];
$ename = "";

if(isset($_POST['submit']))
{
	$c->name = $_POST['name'];
	
	$er = 0;
	
	if($c->name == "")
	{
		$er++;
		$ename = "Required";
	}
	
	if($er == 0)
	{
		if($c->Update())
		{
			print '<span class="success">Country Updated Successfully</span>';	
			
		}
		else
		{
			print '<span class="error">'.$c->error.'</span>';	
		}
	}
}
else
{
	$c->SelectById();
}

$html->BeginForm();
$html->FieldText("name",$c->name);
$html->Error($ename);
$html->BreakLine();
$html->EndForm("Update");
?>
