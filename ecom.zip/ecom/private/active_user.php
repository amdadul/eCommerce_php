<?php
include_once('DAL/activeuser.php');

$au= new activeuser();
$html->NewLink($pageName);

if(isset($_GET['id']))
{
	$au->userId=$_GET['id'];
	if($au->Delete())
	{
		print '<span class="success">Data Deleted Successfully !!! </span>';
	}
	else
	{
		print '<span class="error">'.$au->error.'</span>';
	}
}

$au->pageName=$pageName;
$au->Table("users","");


?>