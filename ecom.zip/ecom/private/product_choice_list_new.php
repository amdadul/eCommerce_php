<?php
include_once('DAL/user.php');
$u = new user();

include_once('DAL/product.php');
$p = new product();

include_once('DAL/productchoicelist.php');
$pcl = new productchoicelist();


$euser = "";
$eproduct="";



if(isset($_POST['submit']))
{
	$pcl->productId = $_POST['product'];
	$pcl->userId = $_POST['user'];
	$pcl->dateTime = date("Y-m-d h:i:s");	
	
	$er = 0;
	
	if($pcl->userId == "0")
	{
		$er++;
		$euser = "Required";
	}
	if($pcl->productId == "0")
	{
		$er++;
		$eproduct = "Required";
	}
	
	if($er == 0)
	{
		if($pcl->Insert())
		{			
			print '<span class="success">Product choice listed Successfully</span>';	
			$pcl = new productchoicelist();
		}
		else
		{
			print '<span class="error">'.$pcl->error.'</span>';	
		}
	}
}

$html->BeginForm();

$html->FieldSelect("product", $p->Option($pcl->productId));
$html->Error($eproduct);
$html->BreakLine();

$html->FieldSelect("user", $u->Option($pcl->userId));
$html->Error($euser);
$html->BreakLine();


$html->EndForm();

?>
