<?php
include_once('DAL/unit.php');

$unit = new unit();
$html->NewLink($pageName);

if(isset($_GET['id']))
{
	$unit->id=$_GET['id'];
	if($unit->Delete())
	{
		print '<span class="success">Data Deleted Successfully !!! </span>';
	}
	else
	{
		print '<span class="error">'.$unit->error.'</span>';
	}
}

$unit->pageName=$pageName;
$unit->Table();


?>