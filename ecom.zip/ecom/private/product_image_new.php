<?php
include_once('DAL/productImage.php');
$pi = new productImage();

include_once('DAL/product.php');
$p = new product();


$eproduct = "";
$eimage = "";

if(isset($_POST['submit']))
{
	$pi->productId = $_POST['product'];
	$pi->image = $_FILES['image'];
	
	$er = 0;
	
	if($pi->productId == "0")
	{
		$er++;
		$eproduct = "Required";
	}
	
	if($pi->image["name"] == "")
	{
		$er++;
		$eimage = "Required";
	}
	else if(!$html->validImage($pi->image["name"]))
	{
		$er++;
		$eimage = "Only JPEG and PNG Supported";	
	}
	else if($pi->image["size"] > (1024 * 1024))
	{
		$er++;
		$eimage = "Must Less Than 1 MB";
	}
	
	if($er == 0)
	{
		if($pi->insert())
		{
			$sp = $pi->image["tmp_name"];
			$dp = "upload/productImage/".$pi->lastId."_".$pi->image["name"];
			
			move_uploaded_file($sp, $dp);
			
			print '<span class="success">Product Image Inserted</span>';
			$pi = new productImage();
		}
		else
		{
			print '<span class="error">'.$pi->error.'</span>';
		}
	}
}

$html->BeginForm('enctype="multipart/form-data"');

$html->FieldSelect("product", $p->Option($pi->productId));
$html->Error($eproduct);
$html->BreakLine();

$html->FieldFile("image");
$html->Error($eimage);
$html->BreakLine();

$html->EndForm();

?>
