<?php
include_once('DAL/product.php');
$p = new product();
$html->NewLink($pageName);

if(isset($_GET['id']))
{
	$p->id=$_GET['id'];
	if($p->Delete())
	{
		print '<span class="success">Data Deleted Successfully !!! </span>';
	}
	else
	{
		print '<span class="error">'.$p->error.'</span>';
	}
}

$table = $p->Select();
print '<table>';
print '<tr><th>Name <br>Code</th><th>Desription</th><th>Unit <br> Brand <br> Category<br>Stock</th><th>Price Info</th><th>Others</th><th>#</th></tr>';

foreach($table as $row)
	{
		print '<tr>';
		print '<td>'.$row["name"].'<br>'.$row["code"].'</td>';
		print '<td><p>'.wordwrap($row["tags"],15,"<br>\n").'</p>';
		print '<p>'.$row["description"].'</p></td>';
		print '<td>Unit : '.$row["unit"].'<br> 
				Brand : '.$row["brand"].'<br>
				Category : '.$row["category"].'<br>
				Stock : '.$row["stock"].'</td>';
		print '<td>Price :'.$row["price"].'<br>
				Vat :'.$row["vat"].' %<br>
				Discount :'.$row["discount"].' %<br>
				<b>Total :'.($row["price"] 
				+ ($row["price"] * $row["vat"] / 100) 
				- ($row["price"] * $row["discount"] / 100)).'</b></td>';
		print '<td>Color : '.$row["color"].'<br>Size : '.$row["size"].'<br>Model : '.$row["model"].'</td>';
		print '<td>
				<a href="?p='.$pageName.'_edit&id='.$row["id"].'">Edit</a> |
					<a href="?p='.$pageName.'&id='.$row["id"].'">Delete</a>
				</td>';
		
		print '</tr>';
	}

print '</table>';
?>