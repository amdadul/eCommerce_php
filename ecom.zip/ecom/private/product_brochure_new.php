<?php
include_once('DAL/productbrochure.php');
$pb = new productBrochure();

include_once('DAL/product.php');
$p = new product();


$eproduct = "";
$ebrochure= "";

if(isset($_POST['submit']))
{
	$pb->productId = $_POST['product'];
	$pb->brochure = $_FILES['brochure'];
	
	$er = 0;
	
	if($pb->productId == "0")
	{
		$er++;
		$eproduct = "Required";
	}
	
	if($pb->brochure["name"] == "")
	{
		$er++;
		$ebrochure = "Required";
	}
	else if(!$html->validFile($pb->brochure["name"]))
	{
		$er++;
		$ebrochure = "Only JPEG and PNG Supported";	
	}
	else if($pb->brochure["size"] > (1024 * 1024 * 3))
	{
		$er++;
		$ebrochure = "Must Less Than 3 MB";
	}
	
	if($er == 0)
	{
		if($pb->insert())
		{
			$sp = $pb->brochure["tmp_name"];
			$dp = "upload/productBrochure/".$pb->productId."_".$pb->brochure["name"];
			
			move_uploaded_file($sp, $dp);
			
			print '<span class="success">Product Brochure Inserted</span>';
			$pi = new productBrochure();
		}
		else
		{
			print '<span class="error">'.$pb->error.'</span>';
		}
	}
}

$html->BeginForm('enctype="multipart/form-data"');

$html->FieldSelect("product", $p->Option($pb->productId));
$html->Error($eproduct);
$html->BreakLine();

$html->FieldFile("brochure");
$html->Error($ebrochure);
$html->BreakLine();

$html->EndForm();

?>
