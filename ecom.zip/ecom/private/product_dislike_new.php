<?php
include_once('DAL/user.php');
$u = new user();

include_once('DAL/product.php');
$p = new product();

include_once('DAL/productdislike.php');
$pdl = new productdislike();


$euser = "";
$eproduct="";



if(isset($_POST['submit']))
{
	$pdl->productId = $_POST['product'];
	$pdl->userId = $_POST['user'];
	$pdl->dateTime = date("Y-m-d h:i:s");	
	
	$er = 0;
	
	if($pdl->userId == "0")
	{
		$er++;
		$euser = "Required";
	}
	if($pdl->productId == "0")
	{
		$er++;
		$eproduct = "Required";
	}
	
	if($er == 0)
	{
		if($pdl->Insert())
		{			
			print '<span class="success">Product Disliked Successfully</span>';	
			$pdl = new productdislike();
		}
		else
		{
			print '<span class="error">'.$pdl->error.'</span>';	
		}
	}
}

$html->BeginForm();

$html->FieldSelect("product", $p->Option($pdl->productId));
$html->Error($eproduct);
$html->BreakLine();

$html->FieldSelect("user", $u->Option($pdl->userId));
$html->Error($euser);
$html->BreakLine();


$html->EndForm();

?>
