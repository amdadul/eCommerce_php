<?php
include_once('DAL/country.php');
$c = new country();
$html->NewLink($pageName);

if(isset($_GET['id']))
{
	$c->id=$_GET['id'];
	if($c->Delete())
	{
		print '<span class="success">Data Deleted Successfully !!! </span>';
	}
	else
	{
		print '<span class="error">'.$c->error.'</span>';
	}
}


$c->pageName = $pageName;
$c->Table();
?>