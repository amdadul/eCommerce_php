<?php
include_once('DAL/color.php');

$cl = new color();
$html->NewLink($pageName);

if(isset($_GET['id']))
{
	$cl->id=$_GET['id'];
	if($cl->Delete())
	{
		print '<span class="success">Data Deleted Successfully !!! </span>';
	}
	else
	{
		print '<span class="error">'.$cl->error.'</span>';
	}
}

$cl->pageName=$pageName;
$cl->Table();


?>