<?php
include_once('DAL/user.php');
$u = new user();

include_once('DAL/loginhistory.php');
$lh = new loginhistory();


$euser = "";



if(isset($_POST['submit']))
{
	$lh->userId = $_POST['user'];
	$lh->dateTime = date("Y-m-d h:i:s");
	$lh->ip = $_SERVER['REMOTE_ADDR'];
	
	
	
	
	$er = 0;
	
	if($lh->userId == "0")
	{
		$er++;
		$euser = "Required";
	}
	
	
	if($er == 0)
	{
		if($lh->Insert())
		{			
			print '<span class="success">login history added Successfully</span>';	
			$lh = new loginhistory();
		}
		else
		{
			print '<span class="error">'.$lh->error.'</span>';	
		}
	}
}

$html->BeginForm();

$html->FieldSelect("user", $u->Option($lh->userId));
$html->Error($euser);
$html->BreakLine();


$html->EndForm();

?>
