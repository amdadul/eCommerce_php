<?php
include_once('DAL/productlike.php');

$pl = new productlike();
$html->NewLink($pageName);

if(isset($_GET['id']))
{
	$pl->productId=$_GET['id'];
	if($pl->Delete())
	{
		print '<span class="success">Data Deleted Successfully !!! </span>';
	}
	else
	{
		print '<span class="error">'.$pl->error.'</span>';
	}
}

$pl->pageName=$pageName;
$pl->Table("like","");


?>