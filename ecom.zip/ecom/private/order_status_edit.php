<?php
include_once('DAL/orders.php');
$o = new orders();
include_once('DAL/status.php');
$s = new status();
include_once('DAL/orderstatus.php');
$os = new orderstatus();
$os->orderId=$_GET['id'];

include_once('DAL/product.php');


$estatus="";
if(isset($_POST['submit']))
{
	
	$os->statusId = $_POST['status'];
		
	
	$er=0;
	
	
	
	
	if($os->statusId=="0")
	{
		$er++;
		$estatus =" Requierd";
	}
	
	
	
if($er==0)
{
	if($os->update())
		{
			print '<span class="success">Order Status updated Successfully</span>';	
			
		}
		else
		{
			print '<span class="error">'.$os->error.'</span>';	
		}
}
}
else
{
	$os->SelectById();
}


$html->BeginForm("","Order Status Entry");


$html->FieldSelect("status", $s->Option($os->statusId));
$html->Error($estatus);
$html->BreakLine();

$html->EndForm();
?>
