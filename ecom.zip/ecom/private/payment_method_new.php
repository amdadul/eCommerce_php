<?php
include_once('DAL/paymentmethod.php');
$s = new paymentmethod();

$ename = "";
$elevel = "";

if(isset($_POST['submit']))
{
	$s->name = $_POST['name'];
	$s->description = $_POST["description"];
	$s->url = $_POST['url'];
	
	$er = 0;
	
	if($s->name == "")
	{
		$er++;
		$ename = "Required";
	}
	
	if($s->url == "")
	{
		$er++;
		$elevel = "Required";
	}
	
	if($er == 0)
	{
		if($s->Insert())
		{
			print '<span class="success">Payment Method Inserted Successfully</span>';	
			$s = new paymentmethod();
		}
		else
		{
			print '<span class="error">Error</span>';	
		}
	}
}

$html->BeginForm();

$html->FieldText("name",$s->name);
$html->Error($ename);
$html->BreakLine();

$html->FieldTextArea("description", $s->description);
$html->BreakLine();

$html->FieldText("url",$s->url);
$html->Error($elevel);
$html->BreakLine();

$html->EndForm();
?>
