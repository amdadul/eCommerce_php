<?php
include_once('DAL/productreview.php');

$prv = new productreview();
$html->NewLink($pageName);

if(isset($_GET['id']))
{
	$prv->id=$_GET['id'];
	if($prv->Delete())
	{
		print '<span class="success">Data Deleted Successfully !!! </span>';
	}
	else
	{
		print '<span class="error">'.$prv->error.'</span>';
	}
}

$prv->pageName=$pageName;
$prv->Table("user","");


?>