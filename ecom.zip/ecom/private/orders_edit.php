<?php
include_once('DAL/orders.php');
$o = new orders();
include_once('DAL/city.php');
$ct = new city();
include_once('DAL/paymentmethod.php');
$pm = new paymentmethod();
include_once('DAL/country.php');
$c = new country();
include_once('DAL/orderstatus.php');
$os = new orderstatus();

$o->id=$_GET['id'];

$eaddress="";
$ecity="";
$epayment="";
$estatus ="";
if(isset($_POST['order']))
{
	$o->Number= date("Y").'_'.date("m").'_'.date("d").'_'.$_SESSION['name'];
	$o->dateTime= date("Y-m-d h:i:s");
	$o->userId = $_SESSION['id'];
	$o->total = $_SESSION['price'];
	$o->vat =0;
	$o->discount = 0;
	if($_POST['city']==1)
	{
		$o->deliveryCharge = 100;
	}
	else
	{
		$o->deliveryCharge = 200;
	}
	$o->deliveryAddress = $_POST['address'];
	$o->cityId = $_POST['city'];
	$o->paymentMethodId = $_POST['payment'];
	
	
	$er=0;
	
	if($o->deliveryAddress=="")
	{
		$er++;
		$eaddress =" Requierd";
	}
	
	if(strlen($o->deliveryAddress)<10)
	{
		$er++;
		$eaddress =" Address Must have 10 Charecter";
	}
	
	if($o->cityId=="0")
	{
		$er++;
		$ecity =" Requierd";
	}
	
	if($o->statusId=="0")
	{
		$er++;
		$estatus =" Requierd";
	}
	
	if($o->paymentMethodId=="0")
	{
		$er++;
		$epayment =" Requierd";
	}
	
if($er==0)
{
	if($o->Update())
		{
			print '<span class="success">Order Updated Successfully</span>';	
			
		}
		else
		{
			print '<span class="error">'.$o->error.'</span>';	
		}
}
}
else
{
	$o->SelectById();
}


$html->BeginForm("","Confirm Order");

$html->FieldTextArea("address",$o->deliveryAddress);
$html->Error($eaddress);
$html->BreakLine();

$html->FieldSelect("city", $ct->Option($o->cityId));
$html->Error($ecity);
$html->BreakLine();

$html->FieldSelect("payment", $pm->Option($o->paymentMethodId));
$html->Error($epayment);
$html->BreakLine();

$html->EndForm("order","order");
?>
