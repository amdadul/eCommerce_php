<?php
include_once('DAL/orders.php');
$o = new orders();
include_once('DAL/status.php');
$s = new status();
include_once('DAL/orderstatus.php');
$os = new orderstatus();


include_once('DAL/product.php');

$eorder="";
$estatus="";
if(isset($_POST['submit']))
{
	$os->orderId= $_POST['order'];
	$os->dateTime= date("Y-m-d h:i:s");
	$os->userId = $_SESSION['id'];
	$os->statusId = $_POST['status'];
		
	
	$er=0;
	
	if($os->orderId=="0")
	{
		$er++;
		$eorder =" Requierd";
	}
	
	
	if($os->statusId=="0")
	{
		$er++;
		$estatus =" Requierd";
	}
	
	
	
if($er==0)
{
	if($os->Insert())
		{
			print '<span class="success">Order Status Submitted Successfully</span>';	
			$os = new orderstatus();
		}
		else
		{
			print '<span class="error">'.$os->error.'</span>';	
		}
}
}


$html->BeginForm("","Order Status Entry");

$html->FieldSelect("order", $o->Ooption($os->orderId));
$html->Error($eorder);
$html->BreakLine();

$html->FieldSelect("status", $s->Option($os->statusId));
$html->Error($estatus);
$html->BreakLine();

$html->EndForm();
?>
