<?php
include_once('DAL/user.php');

$user = new user();
$html->NewLink($pageName);

if(isset($_GET['id']))
{
	$user->id=$_GET['id'];
	if($user->Delete())
	{
		print '<span class="success">Data Deleted Successfully !!! </span>';
	}
	else
	{
		print '<span class="error">'.$user->error.'</span>';
	}
}

$user->pageName=$pageName;
$user->Table();


?>