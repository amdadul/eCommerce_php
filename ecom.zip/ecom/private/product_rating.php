<?php
include_once('DAL/productrating.php');

$pr = new productrating();
$html->NewLink($pageName);

if(isset($_GET['id']))
{
	$pr->id=$_GET['id'];
	if($pr->Delete())
	{
		print '<span class="success">Data Deleted Successfully !!! </span>';
	}
	else
	{
		print '<span class="error">'.$pr->error.'</span>';
	}
}

$pr->pageName=$pageName;
$pr->Table("rating","");


?>