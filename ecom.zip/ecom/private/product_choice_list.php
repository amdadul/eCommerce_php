<?php
include_once('DAL/productchoicelist.php');

$pcl = new productchoicelist();
$html->NewLink($pageName);

if(isset($_GET['id']))
{
	$pcl->id=$_GET['id'];
	if($pcl->Delete())
	{
		print '<span class="success">Data Deleted Successfully !!! </span>';
	}
	else
	{
		print '<span class="error">'.$pcl->error.'</span>';
	}
}

$pcl->pageName=$pageName;
$pcl->Table();


?>