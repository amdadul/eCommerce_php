<?php
include_once('DAL/brand.php');
$b = new brand();

$ename = "";

if(isset($_POST['submit']))
{
	$b->name = $_POST['name'];
	$b->description = $_POST["description"];
	
	$er = 0;
	
	if($b->name == "")
	{
		$er++;
		$ename = "Required";
	}
	
	if($er == 0)
	{
		if($b->Insert())
		{
			print '<span class="success">Brand Inserted Successfully</span>';	
			$b = new brand();
		}
		else
		{
			print '<span class="error">Error</span>';	
		}
	}
}

$html->BeginForm();

$html->FieldText("name",$b->name);
$html->Error($ename);
$html->BreakLine();

$html->FieldTextArea("description", $b->description);
$html->BreakLine();

$html->EndForm();
?>