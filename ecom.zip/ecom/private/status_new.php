<?php
include_once('DAL/status.php');
$s = new status();

$ename = "";
$elevel = "";

if(isset($_POST['submit']))
{
	$s->name = $_POST['name'];
	$s->description = $_POST["description"];
	$s->level = $_POST['level'];
	
	$er = 0;
	
	if($s->name == "")
	{
		$er++;
		$ename = "Required";
	}
	
	if($s->level == "")
	{
		$er++;
		$elevel = "Required";
	}
	
	if($er == 0)
	{
		if($s->Insert())
		{
			print '<span class="success">Status Inserted Successfully</span>';	
			$s = new status();
		}
		else
		{
			print '<span class="error">Error</span>';	
		}
	}
}

$html->BeginForm();

$html->FieldText("name",$s->name);
$html->Error($ename);
$html->BreakLine();

$html->FieldTextArea("description", $s->description);
$html->BreakLine();

$html->FieldText("level",$s->level);
$html->Error($elevel);
$html->BreakLine();

$html->EndForm();
?>
