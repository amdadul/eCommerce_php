<?php
include_once('DAL/user.php');
$u = new user();

include_once('DAL/product.php');
$p = new product();

include_once('DAL/productreview.php');
$pr = new productreview();


$euser = "";
$eproduct="";
$ereview ="";



if(isset($_POST['submit']))
{
	$pr->productId = $_POST['product'];
	$pr->userId = $_SESSION['id'];
	$pr->review = $_POST['review'];
	$pr->dateTime = date("Y-m-d h:i:s");	
	
	$er = 0;
	
	
	if($pr->productId == "0")
	{
		$er++;
		$eproduct = "Required";
	}
	
	if($pr->review == "")
	{
		$er++;
		$ereview = "Required";
	}
	
	if($er == 0)
	{
		if($pr->Insert())
		{			
			print '<span class="success">Review Added Successfully</span>';	
			$pr = new productreview();
		}
		else
		{
			print '<span class="error">'.$pr->error.'</span>';	
		}
	}
}

$html->BeginForm();

$html->FieldSelect("product", $p->Option($pr->productId));
$html->Error($eproduct);
$html->BreakLine();



$html->FieldTextArea("review",$pr->review);
$html->Error($ereview);
$html->BreakLine();


$html->EndForm();

?>
