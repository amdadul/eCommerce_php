<?php
include_once('DAL/category.php');
$c = new category();

$ename = "";

if(isset($_POST['submit']))
{
	$c->name = $_POST['name'];
	$c->description = $_POST["description"];
	$c->categoryId = $_POST['category'];
	
	$er = 0;
	
	if($c->name == "")
	{
		$er++;
		$ename = "Required";
	}
	
	if($er == 0)
	{
		if($c->Insert())
		{
			print '<span class="success">Category Inserted Successfully</span>';	
			$c = new category();
		}
		else
		{
			print '<span class="error">Error</span>';	
		}
	}
}

$html->BeginForm();

$html->FieldText("name",$c->name);
$html->Error($ename);
$html->BreakLine();

$html->FieldTextArea("description",$c->description);
$html->BreakLine();

$html->FieldSelect("category", $c->Option($c->categoryId));
$html->BreakLine();

$html->EndForm();

?>