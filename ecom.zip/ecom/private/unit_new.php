<?php
include_once('DAL/unit.php');
$u = new unit();

$ename = "";

if(isset($_POST['submit']))
{
	$u->name = $_POST['name'];
	$u->description = $_POST["description"];
	
	$er = 0;
	
	if($u->name == "")
	{
		$er++;
		$ename = "Required";
	}
	
	if($er == 0)
	{
		if($u->Insert())
		{
			print '<span class="success">Unit Inserted Successfully</span>';	
			$u = new unit();
		}
		else
		{
			print '<span class="error">Error</span>';	
		}
	}
}

$html->BeginForm();

$html->FieldText("name",$u->name);
$html->Error($ename);
$html->BreakLine();

$html->FieldTextArea("description", $u->description);
$html->BreakLine();

$html->EndForm();
?>
