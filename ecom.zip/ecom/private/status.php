<?php
include_once('DAL/status.php');

$status = new status();
$html->NewLink($pageName);

if(isset($_GET['id']))
{
	$status->id=$_GET['id'];
	if($status->Delete())
	{
		print '<span class="success">Data Deleted Successfully !!! </span>';
	}
	else
	{
		print '<span class="error">'.$status->error.'</span>';
	}
}

$status->pageName=$pageName;
$status->Table();


?>