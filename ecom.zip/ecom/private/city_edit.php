<?php
include_once('DAL/city.php');
$ct = new city();
include_once('DAL/country.php');
$c = new country();
$ct->id = $_GET['id'];
$ename = "";
$ecountry = "";

if(isset($_POST['submit']))
{
	$ct->name = $_POST['name'];
	$ct->countryId = $_POST['country'];
	
	$er = 0;
	
	if($ct->name == "")
	{
		$er++;
		$ename = "Required";
	}
	
	if($ct->countryId == "0")
	{
		$er++;
		$ecountry = "Required";
	}
	
	if($er == 0)
	{
		if($ct->Update())
		{
			print '<span class="success">City Updated Successfully</span>';	
			
		}
		else
		{
			print '<span class="error">Error</span>';	
		}
	}
}
else
{
	$ct->SelectById();
}

$html->BeginForm();

$html->FieldText("name",$ct->name);
$html->Error($ename);
$html->BreakLine();

$html->FieldSelect("country", $c->Option($ct->countryId));
$html->Error($ecountry);
$html->BreakLine();

$html->EndForm("Update");
?>