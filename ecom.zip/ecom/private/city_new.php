<?php
include_once('DAL/city.php');
$ct = new city();
include_once('DAL/country.php');
$c = new country();

$ename = "";
$ecountry = "";

if(isset($_POST['submit']))
{
	$ct->name = $_POST['name'];
	$ct->countryId = $_POST['country'];
	
	$er = 0;
	
	if($ct->name == "")
	{
		$er++;
		$ename = "Required";
	}
	
	if($ct->countryId == "0")
	{
		$er++;
		$ecountry = "Required";
	}
	
	if($er == 0)
	{
		if($ct->Insert())
		{
			print '<span class="success">City Inserted Successfully</span>';	
			$ct = new city();
		}
		else
		{
			print '<span class="error">Error</span>';	
		}
	}
}
$html->BeginForm();

$html->FieldText("name",$ct->name);
$html->Error($ename);
$html->BreakLine();

$html->FieldSelect("country", $c->Option($ct->countryId));
$html->Error($ecountry);
$html->BreakLine();

$html->EndForm();
?>