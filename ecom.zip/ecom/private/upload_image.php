<?php
include_once('DAL/user.php');
$u = new user();
$u->id = $_SESSION['id'];
include_once('DAL/city.php');
$c = new city();



$eimage = "";


if(isset($_POST['submit']))
{
	$u->image = $_FILES['image'];
	
	
	
	$er = 0;
	
	
	if($u->image["name"] == "")
	{
		$er++;
		$eimage = "Required";
	}
	else if(!$html->validImage($u->image["name"]))
	{
		$er++;
		$eimage = "Only JPEG and PNG Supported";	
	}
	else if($u->image["size"] > (1024 * 1024))
	{
		$er++;
		$eimage = "Must Less Than 1 MB";
	}
	
	
	if($er == 0)
	{
		if($u->Iupdate())
		{
			$sp = $u->image["tmp_name"];
			$dp = "upload/userImage/".$u->lastId."_".$u->image["name"];
			
			move_uploaded_file($sp, $dp);
			
			
			print '<span class="success">Profile Updated  Successfully</span>';	
			$u = new user();
		}
		else
		{
			print '<span class="error">'.$u->error.'</span>';	
		}
	}
}
else
{
	$u->SelectById();
}

$html->BeginForm('enctype="multipart/form-data"');

$html->FieldFile("image");
$html->Error($eimage);
$html->BreakLine();


$html->EndForm("submit","Update");

?>
