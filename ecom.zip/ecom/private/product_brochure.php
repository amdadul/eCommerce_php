<?php
$html->NewLink($pageName);
include_once('DAL/productbrochure.php');
$pb = new productBrochure();

if(isset($_GET['id']))
{
	$pb->productId=$_GET['id'];
	if($pb->Delete())
	{
		print '<span class="success">Data Deleted Successfully !!! </span>';
	}
	else
	{
		print '<span class="error">'.$pb->error.'</span>';
	}
}

$pb->pageName=$pageName;
$pb->Table("brochure",'<a href="upload/productBrochure/#replace#">View</a>');


?>