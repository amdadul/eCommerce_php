<?php
include_once('DAL/orderstatus.php');

$ords = new orderstatus();
$html->NewLink($pageName);

if(isset($_GET['id']))
{
	$ords->id=$_GET['id'];
	if($ords->Delete())
	{
		print '<span class="success">Data Deleted Successfully !!! </span>';
	}
	else
	{
		print '<span class="error">'.$ords->error.'</span>';
	}
}
$ords->pageName=$pageName;
$ords->Table("orderst","");



?>