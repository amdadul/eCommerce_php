<?php
include_once('DAL/paymentmethod.php');

$payment = new paymentmethod();
$html->NewLink($pageName);

if(isset($_GET['id']))
{
	$payment->id=$_GET['id'];
	if($payment->Delete())
	{
		print '<span class="success">Data Deleted Successfully !!! </span>';
	}
	else
	{
		print '<span class="error">'.$payment->error.'</span>';
	}
}

$payment->pageName=$pageName;
$payment->Table();


?>