<?php
include_once('DAL/user.php');
$u = new user();

include_once('DAL/product.php');
$p = new product();

include_once('DAL/productlike.php');
$pl = new productlike();


$euser = "";
$eproduct="";



if(isset($_POST['submit']))
{
	$pl->productId = $_POST['product'];
	$pl->userId = $_POST['user'];
	$pl->dateTime = date("Y-m-d h:i:s");	
	
	$er = 0;
	
	if($pl->userId == "0")
	{
		$er++;
		$euser = "Required";
	}
	if($pl->productId == "0")
	{
		$er++;
		$eproduct = "Required";
	}
	
	if($er == 0)
	{
		if($pl->Insert())
		{			
			print '<span class="success">Product liked Successfully</span>';	
			$pl = new productlike();
		}
		else
		{
			print '<span class="error">'.$pl->error.'</span>';	
		}
	}
}

$html->BeginForm();

$html->FieldSelect("product", $p->Option($pl->productId));
$html->Error($eproduct);
$html->BreakLine();

$html->FieldSelect("user", $u->Option($pl->userId));
$html->Error($euser);
$html->BreakLine();


$html->EndForm();

?>
