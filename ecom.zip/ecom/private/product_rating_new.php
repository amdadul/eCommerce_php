<?php
include_once('DAL/user.php');
$u = new user();

include_once('DAL/product.php');
$p = new product();

include_once('DAL/productrating.php');
$pr = new productrating();


$euser = "";
$eproduct="";
$erating ="";



if(isset($_POST['submit']))
{
	$pr->productId = $_POST['product'];
	$pr->userId = $_POST['user'];
	
	if(isset($_POST['rating']))
		$pr->ratings = $_POST['rating'];
	
	$pr->dateTime = date("Y-m-d h:i:s");	
	
	$er = 0;
	
	if($pr->userId == "0")
	{
		$er++;
		$euser = "Required";
	}
	if($pr->productId == "0")
	{
		$er++;
		$eproduct = "Required";
	}
	
	if($pr->ratings == "")
	{
		$er++;
		$erating = "Required";
	}
	
	if($er == 0)
	{
		if($pr->Insert())
		{			
			print '<span class="success">Product Rated Successfully</span>';	
			$pr = new productrating();
		}
		else
		{
			print '<span class="error">'.$pr->error.'</span>';	
		}
	}
}

$html->BeginForm();

$html->FieldSelect("product", $p->Option($pr->productId));
$html->Error($eproduct);
$html->BreakLine();

$html->FieldSelect("user", $u->Option($pr->userId));
$html->Error($euser);
$html->BreakLine();

$html->FieldRadio("ratings","rating",1);
$html->Error($erating);
$html->FieldRadio("","rating",2);

$html->FieldRadio("","rating",3);

$html->FieldRadio("","rating",4);

$html->FieldRadio("","rating",5);

$html->BreakLine();


$html->EndForm();

?>
