<?php

	print '<span class="success">You Have been Loged in Successfully</span>';

?>