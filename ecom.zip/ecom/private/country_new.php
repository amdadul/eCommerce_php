<?php
include_once('DAL/country.php');
$c = new country();

$ename = "";

if(isset($_POST['submit']))
{
	$c->name = $_POST['name'];
	
	$er = 0;
	
	if($c->name == "")
	{
		$er++;
		$ename = "Required";
	}
	
	if($er == 0)
	{
		if($c->Insert())
		{
			print '<span class="success">Country Inserted Successfully</span>';	
			$c = new country();
		}
		else
		{
			print '<span class="error">Error</span>';	
		}
	}
}
$html->BeginForm();
$html->FieldText("name",$c->name);
$html->Error($ename);
$html->BreakLine();
$html->EndForm();
?>
