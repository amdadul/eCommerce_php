<?php
include_once('DAL/orderdetails.php');

$od = new orderdetails();
$html->NewLink($pageName);

if(isset($_GET['id']))
{
	$od->id=$_GET['id'];
	if($od->Delete())
	{
		print '<span class="success">Data Deleted Successfully !!! </span>';
	}
	else
	{
		print '<span class="error">'.$od->error.'</span>';
	}
}

$od->pageName=$pageName;
$od->Table();


?>