<?php
include_once('DAL/brand.php');

$b = new brand();
$html->NewLink($pageName);

if(isset($_GET['id']))
{
	$b->id=$_GET['id'];
	if($b->Delete())
	{
		print '<span class="success">Data Deleted Successfully !!! </span>';
	}
	else
	{
		print '<span class="error">'.$b->error.'</span>';
	}
}

$b->pageName=$pageName;
$b->Table();


?>