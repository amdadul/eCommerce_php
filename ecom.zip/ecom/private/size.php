<?php
include_once('DAL/size.php');
$s = new size();
$html->NewLink($pageName);

if(isset($_GET['id']))
{
	$s->id=$_GET['id'];
	if($s->Delete())
	{
		print '<span class="success">Data Deleted Successfully !!! </span>';
	}
	else
	{
		print '<span class="error">'.$s->error.'</span>';
	}
}

$s->pageName=$pageName;
$s->Table();
?>