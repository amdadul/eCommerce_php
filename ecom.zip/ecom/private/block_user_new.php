<?php
include_once('DAL/user.php');
$u = new user();

include_once('DAL/blockuser.php');
$bu = new blockuser();


$euser = "";
$eblockto = "";
$eblockby = "";



if(isset($_POST['submit']))
{
	$bu->userId = $_POST['user'];
	$bu->blockFrom = date("Y-m-d h:i:s");
	$bu->blockTo = $_POST['blockTo'];
	$bu->blockByUserId = $_POST["blockby"];
	$bu->remarks = $_POST['remarks'];
	
	
	
	
	$er = 0;
	
	if($bu->userId == "0")
	{
		$er++;
		$euser = "Required";
	}
	if($bu->blockTo == "")
	{
		$er++;
		$eblockto = "Required";
	}
	
	if($bu->blockByUserId == "0")
	{
		$er++;
		$eblockby = "Required";
	}
	
	
	
	if($er == 0)
	{
		if($bu->Insert())
		{			
			print '<span class="success">User Blocked Successfully</span>';	
			$bu = new blockuser();
		}
		else
		{
			print '<span class="error">'.$bu->error.'</span>';	
		}
	}
}

$html->BeginForm();

$html->FieldSelect("user", $u->Option($bu->userId));
$html->Error($euser);
$html->BreakLine();

$html->FieldText("blockTo", $bu->blockTo);
$html->Error($eblockto);
$html->BreakLine();

$html->FieldSelect("blockby", $u->Option($bu->blockByUserId));
$html->Error($eblockby);
$html->BreakLine();

$html->FieldTextArea("remarks", $bu->remarks);
$html->BreakLine();


$html->EndForm();

?>
