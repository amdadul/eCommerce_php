<?php
include_once('DAL/productdislike.php');

$pdl = new productdislike();
$html->NewLink($pageName);

if(isset($_GET['id']))
{
	$pdl->productId=$_GET['id'];
	if($pdl->Delete())
	{
		print '<span class="success">Data Deleted Successfully !!! </span>';
	}
	else
	{
		print '<span class="error">'.$pdl->error.'</span>';
	}
}

$pdl->pageName=$pageName;
$pdl->Table("dislike","");


?>