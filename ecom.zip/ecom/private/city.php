<?php
include_once('DAL/city.php');
$ct = new city();
$html->NewLink($pageName);

if(isset($_GET['id']))
{
	$ct->id=$_GET['id'];
	if($ct->Delete())
	{
		print '<span class="success">Data Deleted Successfully !!! </span>';
	}
	else
	{
		print '<span class="error">'.$ct->error.'</span>';
	}
}

$ct->pageName=$pageName;
$ct->Table();
?>