<?php

include_once('DAL/product.php');
$p = new product();


include_once('DAL/unit.php');
$u = new unit();

include_once('DAL/brand.php');
$b = new brand();

include_once('DAL/category.php');
$c = new category();

include_once('DAL/size.php');
$s = new size();

include_once('DAL/color.php');
$clr = new color();

include_once('DAL/user.php');
$usr = new user();

$ename = "";
$ecode ="";
$etags ="";
$eunit ="";
$ebrand ="";
$ecategory ="";
$eprice ="";
$evat ="";
$ediscount ="";
$estock ="";
$emodel ="";
$esize ="";
$ecolor ="";
  
  $p->id=$_GET['id'];
  
if(isset($_POST['submit']))
{
	$p->name = $_POST['name'];
	$p->code = $_POST['code'];
	$p->tags = $_POST['tags'];
	$p->description = $_POST["description"];
	$p->unitId = $_POST['unit'];
	$p->brandId = $_POST['brand'];
	$p->categoryId = $_POST['category'];
	$p->price= $_POST['price'];
	$p->vat = $_POST['vat'];
	$p->discount = $_POST['discount'];
	$p->stock = $_POST['stock'];
	$p->model = $_POST['model'];
	$p->sizeId = $_POST['size'];
	$p->colorId = $_POST['color'];
	$p->ip = $_SERVER['REMOTE_ADDR'];
	$p->userId = $_SESSION["id"];
	
	$er = 0;
	
	if($p->name == "")
	{
		$er++;
		$ename = "Required";
	}
	
	if($p->code == "")
	{
		$er++;
		$ecode = "Required";
	}
	
	if($p->tags == "")
	{
		$er++;
		$etags = "Required";
	}
	
	if($p->unitId == "0")
	{
		$er++;
		$eunit = "Required";
	}
	
	if($p->brandId == "0")
	{
		$er++;
		$ebrand = "Required";
	}
	
	if($p->categoryId == "0")
	{
		$er++;
		$ecategory = "Required";
	}
	
	if($p->price == "")
	{
		$er++;
		$eprice = "Required";
	}
	
	if($p->vat == "")
	{
		$er++;
		$evat = "Required";
	}
	
	if($p->discount == "")
	{
		$er++;
		$ediscount = "Required";
	}
	
	if($p->stock == "")
	{
		$er++;
		$estock = "Required";
	}
	
	if($p->model == "")
	{
		$er++;
		$emodel = "Required";
	}
	
	if($p->sizeId == "0")
	{
		$er++;
		$esize = "Required";
	}
	
	if($p->colorId == "0")
	{
		$er++;
		$ecolor = "Required";
	}
	
	if($er == 0)
	{
		if($p->Update())
		{
			print '<span class="success">Product Updated Successfully</span>';	
			
		}
		else
		{
			print '<span class="error">'.$p->error.'</span>';	
		}
	}
}
else
{
	$p->SelectById();
}

$html->BeginForm();

$html->FieldText("name",$p->name);
$html->Error($ename);
$html->BreakLine();

$html->FieldText("code",$p->code);
$html->Error($ecode);
$html->BreakLine();

$html->FieldText("tags",$p->tags);
$html->Error($etags);
$html->BreakLine();

$html->FieldTextArea("description",$p->description);
$html->BreakLine();

$html->FieldSelect("unit", $u->Option($p->unitId));
$html->Error($eunit);
$html->BreakLine();

$html->FieldSelect("brand", $b->Option($p->brandId));
$html->Error($ebrand);
$html->BreakLine();

$html->FieldSelect("category", $c->Option($p->categoryId));
$html->Error($ecategory);
$html->BreakLine();

$html->FieldText("price",$p->price);
$html->Error($eprice);
$html->BreakLine();

$html->FieldText("vat",$p->vat);
$html->Error($evat);
$html->BreakLine();

$html->FieldText("discount",$p->discount);
$html->Error($ediscount);
$html->BreakLine();

$html->FieldText("stock",$p->stock);
$html->Error($estock);
$html->BreakLine();

$html->FieldText("model",$p->model);
$html->Error($emodel);
$html->BreakLine();

$html->FieldSelect("size", $s->Option($p->sizeId));
$html->Error($esize);
$html->BreakLine();

$html->FieldSelect("color", $clr->Option($p->colorId));
$html->Error($ecolor);
$html->BreakLine();

$html->EndForm("submit","Update");

?>