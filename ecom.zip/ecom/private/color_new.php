<?php
include_once('DAL/color.php');
$cl = new color();

$ename = "";

if(isset($_POST['submit']))
{
	$cl->name = $_POST['name'];
	$cl->description = $_POST["description"];
	
	$er = 0;
	
	if($cl->name == "")
	{
		$er++;
		$ename = "Required";
	}
	
	if($er == 0)
	{
		if($cl->Insert())
		{
			print '<span class="success">Color Inserted Successfully</span>';	
			$cl = new color();
		}
		else
		{
			print '<span class="error">Error</span>';	
		}
	}
}

$html->BeginForm();

$html->FieldText("name",$cl->name);
$html->Error($ename);
$html->BreakLine();

$html->FieldTextArea("description", $cl->description);
$html->BreakLine();

$html->EndForm();

?>
