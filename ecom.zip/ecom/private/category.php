<?php
include_once('DAL/category.php');

$cat = new category();
$html->NewLink($pageName);

if(isset($_GET['id']))
{
	$cat->id=$_GET['id'];
	if($cat->Delete())
	{
		print '<span class="success">Data Deleted Successfully !!! </span>';
	}
	else
	{
		print '<span class="error">'.$cat->error.'</span>';
	}
}

$cat->pageName=$pageName;
$cat->Table();


?>