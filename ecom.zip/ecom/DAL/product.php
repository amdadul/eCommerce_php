<?php

class product extends base
{
	public $id;
	public $name;
	public $code;
	public $tags;
	public $description;
	public $unitId;
	public $brandId;
	public $categoryId;
	public $price;
	public $vat;
	public $discount;
	public $stock;
	public $model;
	public $sizeId;
	public $colorId;
	public $ip;
	public $userId;

	
	public function Insert()
	{
		$sql = "insert into product(name, code , tags, description, unitId, brandId, categoryId, price, vat, discount, stock, model, sizeId, colorId, ip, userId
) values(
		'".$this->SD($this->name)."',
		'".$this->SD($this->code)."',
		'".$this->SD($this->tags)."',
		'".$this->SD($this->description)."',
		".$this->SD($this->unitId).",
		".$this->SD($this->brandId).",
		".$this->SD($this->categoryId).",
		".$this->SD($this->price).",
		".$this->SD($this->vat).",
		".$this->SD($this->discount).",
		".$this->SD($this->stock).",
		'".$this->SD($this->model)."',
		".$this->SD($this->sizeId).",
		".$this->SD($this->colorId).",
		'".$this->SD($this->ip)."',
		".$this->SD($this->userId)."
		)";
		return $this->Execute($sql);
		
	}
	
	public function Update()
	{
		$sql = "update product set 
			name = '".$this->SD($this->name)."',
			code = '".$this->SD($this->code)."',
			tags = '".$this->SD($this->tags)."',
			description = '".$this->SD($this->description)."',
			unitId = ".$this->SD($this->unitId).",
			brandId = ".$this->SD($this->brandId).",
			categoryId = ".$this->SD($this->categoryId).",
			price = ".$this->SD($this->price).",
			vat = ".$this->SD($this->vat).",
			discount = ".$this->SD($this->discount).",
			stock = ".$this->SD($this->stock).",
			model = '".$this->SD($this->model)."',
			sizeId = ".$this->SD($this->sizeId).",
			colorId = ".$this->SD($this->colorId).",
			iP = '".$this->SD($this->ip)."',
			userId = ".$this->SD($this->userId)."			
			 where id = ".$this->id;
				
		return $this->Execute($sql);
	}
	
	public function Delete()
	{
		$sql = "delete from product where id = ".$this->id;
		return $this->Execute($sql);
	}
	
	public function SelectById()
	{
		$sql = "select id, name, code , tags, description, unitId, brandId, categoryId, price, vat, discount, stock, model, sizeId, colorId, ip, userId from product where id = ".$this->id;
		
		$a = $this->SelectRow($sql);
		if(count($a) > 0)
		{
			$this->name = $a["name"];
			$this->code= $a["code"];
			$this->tags = $a["tags"];
			$this->description = $a["description"];
			$this->unitId = $a["unitId"];
			$this->brandId = $a["brandId"];
			$this->categoryId = $a["categoryId"];
			$this->price = $a["price"];
			$this->vat = $a["vat"];
			$this->discount = $a["discount"];
			$this->stock = $a["stock"];
			$this->model = $a["model"];
			$this->sizeId = $a["sizeId"];
			$this->colorId = $a["colorId"];
			$this->ip = $a["ip"];
			$this->userId = $a["userId"];

			return true;
		}
		return false;
	}
	
	public function Select()
	{
		$sql = "select p.id, p.name, p.code, p.tags, p.description, u.name unit,b.name brand, c.name category, p.price, p.vat, p.discount, p.stock, p.model, s.name size, clr.name color,p.ip,usr.name user
		from product p
		left join unit u on p.unitId = u.id
		left join brand b on p.brandId = b.id 
		left join category c on p.categoryId = c.id 
		left join size s on p.sizeId = s.id 
		left join color clr on p.colorId = clr.id
		left join user usr on p.userId = usr.id  ";
		
		if($this->id > 0)
		{
			$sql .="where p.id =".$this->SD($this->id);
		}
		
		if($this->categoryId > 0)
		{
			$sql .="where p.categoryId =".$this->SD($this->categoryId);
		}

		return $this->selectQuery($sql);
	}
}


?>