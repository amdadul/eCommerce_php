<?php
session_start();
include_once('DAL/base.php');
include_once('shared/htmlHelper.php');
$html = new htmlHelper();
date_default_timezone_set("Asia/Dhaka");
include_once("shared/header.php");

if(isset($_GET['p']))
{
	include_once("shared/adminLayout.php");
}
else
{
	include_once("shared/clientLayout.php");
}

?>
