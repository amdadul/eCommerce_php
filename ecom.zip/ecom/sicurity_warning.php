<style>
h1{color:rgba(252,7,11,1.00);}
.span{color:rgba(47,7,247,1.00);}
</style>

<h1>You have been trying to violated our system. we have save your details as beloow to uor server for further investigation.</h1><br><hr>

<?php
//foreach($_SERVER as $k=>$v)
//{
	//print '<b>'.$k.' : </b> <span class="span"> '.$v.' </span><br>';
	print '
	<b>HTTP_USER_AGENT : </b><span class="span">'.$_SERVER["HTTP_USER_AGENT"].'</span><br>
	<b>HTTP_ACCEPT : </b><span class="span">'.$_SERVER["HTTP_ACCEPT"].'</span><br>
	<b>HTTP_ACCEPT_LANGUAGE : </b><span class="span">'.$_SERVER["HTTP_ACCEPT_LANGUAGE"].'</span><br>
	<b>HTTP_ACCEPT_ENCODING : </b><span class="span">'.$_SERVER["HTTP_ACCEPT_ENCODING"].'</span><br>
	<b>HTTP_CONNECTION : </b><span class="span">'.$_SERVER["HTTP_CONNECTION"].'</span><br>
	<b>HTTP_UPGRADE_INSECURE_REQUESTS : </b><span class="span">'.$_SERVER["HTTP_UPGRADE_INSECURE_REQUESTS"].'</span><br>
	<b>PATH : </b><span class="span">'.$_SERVER["PATH"].'</span><br>
	<b>REMOTE_ADDR : </b><span class="span">'.$_SERVER["REMOTE_ADDR"].'</span><br>
	<b>REQUEST_SCHEME : </b><span class="span">'.$_SERVER["REQUEST_SCHEME"].'</span><br>
	<b>REMOTE_PORT : </b><span class="span">'.$_SERVER["REMOTE_PORT"].'</span><br>
	<b>GATEWAY_INTERFACE : </b><span class="span">'.$_SERVER["GATEWAY_INTERFACE"].'</span><br>
	<b>QUERY_STRING : </b><span class="span">'.$_SERVER["QUERY_STRING"].'</span><br>
	<b>REQUEST_TIME : </b><span class="span">'.$_SERVER["REQUEST_TIME"].'</span><br> ';
		
	
//}

?>